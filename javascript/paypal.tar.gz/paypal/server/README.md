Code Exercise readme

Used Jquery as library

Avoid using express or angularjs as they provide router and template implementation

Accomplished:

- Navigation using Jquery
- Node JS deliver partial records

-Missing:

- validation routine in capture
- Infinite scroll (provided "get more" link)

